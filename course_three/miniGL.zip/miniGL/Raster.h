#pragma once

class Raster
{
public:
	static void drawCell(int row, int col , unsigned color );
	static void drawGrid();
};

